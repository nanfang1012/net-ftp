#!/usr/bin/env bash
set -euo pipefail

# ==============================
# 解析命令行参数
# ==============================
VERSION=""
REL="1"  # 默认 Release

while getopts "v:r:" opt; do
  case "$opt" in
    v) VERSION="$OPTARG" ;;
    r) REL="$OPTARG" ;;
    *) echo "用法: $0 -v VERSION [-r RELEASE]"; exit 1 ;;
  esac
done

# ==============================
# 必须指定 VERSION
# ==============================
if [ -z "$VERSION" ]; then
  echo "错误：必须通过 -v 指定版本号"
  echo "用法: $0 -v VERSION [-r RELEASE]"
  exit 1
fi

echo "使用版本: ${VERSION}"
echo "使用 Release: ${REL}"

# ==============================
# 路径定义
# ==============================
SRC_WORKDIR="/home/git-code/CameraFaceDetection"
DOCKER_IMAGE="face_capture-build-pyinstaller-d2000-py3.9.9"
RPMBUILD_DIR="/root/rpmbuild"
TARGET_DIR="${RPMBUILD_DIR}/SOURCES/face-capture-oa-d2000/opt/Cam"
SPEC_PATH="${RPMBUILD_DIR}/SPECS/face-capture-oa-d2000.spec"

cd "${SRC_WORKDIR}"

# ==============================
# 写 VERSION 文件
# ==============================
echo "${VERSION}" > VERSION

# ==============================
# 使用 Docker + PyInstaller 打包
# ==============================
docker run --rm -v "$PWD":/workspace "${DOCKER_IMAGE}" \
  pyinstaller --clean  face_capture_oa_d2000.spec

# ==============================
# 检查产物
# ==============================
DIST_DIR="${SRC_WORKDIR}/dist"

if [ ! -d "${DIST_DIR}" ]; then
  echo "错误：找不到 dist 目录 ${DIST_DIR}"
  exit 2
fi

# ==============================
# 拷贝到 RPM SOURCES 目录
# ==============================
mkdir -p "${TARGET_DIR}"
cp -rf "${DIST_DIR}/face_capture_oa_d2000" "${TARGET_DIR}/face_capture"

# ==============================
# 构建 RPM
# ==============================
cd "${RPMBUILD_DIR}"
rpmbuild -bb --clean \
  --define "ver ${VERSION}" \
  --define "rel ${REL}" \
  "${SPEC_PATH}"

# ==============================
# 输出生成的 RPM 文件路径
# ==============================
RPM_OUTPUT_DIR="${RPMBUILD_DIR}/RPMS/$(uname -m)"
echo "=========================="
echo "RPM 构建完成: ${VERSION}-${REL}"
echo "生成的 RPM 文件路径如下:"
ls -1 "${RPM_OUTPUT_DIR}/face-capture-oa-d2000-${VERSION}-${REL}"*.rpm || echo "未找到 RPM 文件"
echo "=========================="

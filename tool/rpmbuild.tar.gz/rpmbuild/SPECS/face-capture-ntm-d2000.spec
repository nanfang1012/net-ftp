# 默认值
%{!?ver: %define ver 1.0.0}
%{!?rel: %define rel 1}

Name:           face-capture-ntm-d2000
Version:        %{ver}
Release:        %{rel}%{?dist}
Summary:        Camera capture startup service
%global debug_package %{nil}
License:        GPL
Group:          System Environment/Base

%description
face-capture 是一个摄像头捕获启动服务，会在系统启动时自动运行 /opt/Cam/face_capture。

%prep
%setup -q -c -T
cp -r %{_sourcedir}/face-capture-ntm-d2000/* .

%build
# 无需编译

%install
mkdir -p %{buildroot}/opt/Cam
mkdir -p %{buildroot}/etc/systemd/system

# 先拷贝源码中已有文件（如果存在）
cp -r opt/Cam/* %{buildroot}/opt/Cam/ 2>/dev/null || true
cp etc/systemd/system/face-capture.service %{buildroot}/etc/systemd/system/ 2>/dev/null || true

MOUNT_PATH="/opt/Cam"

# 设置权限（确保可执行）
chmod 755 %{buildroot}/opt/Cam/face_capture 2>/dev/null || true
chmod 664 %{buildroot}/opt/Cam/auth_method.json 2>/dev/null || true

%post
systemctl daemon-reload
systemctl enable face-capture.service
systemctl restart face-capture.service || true


%preun
if [ $1 -eq 0 ]; then
    systemctl stop face-capture.service || true
    systemctl disable face-capture.service || true
fi

%files
/opt/Cam
%config(noreplace) /opt/Cam/auth_method.json
/etc/systemd/system/face-capture.service

%changelog
* Sun Nov 30 2025 Yuanbao <admin@example.com> - %{ver}-%{rel}
- Initial release
